Unzip entire folder.


Report folder contains the report in both doxc and PDF format
Images contain basic images including the images provided and methodology diagram.
Code includes all the code used (also included in report appendix for refernece)
Contribuiton sheet folder contains the contribuiton sheet in both doxc and PDF format

Report by 29015642, 29021376

