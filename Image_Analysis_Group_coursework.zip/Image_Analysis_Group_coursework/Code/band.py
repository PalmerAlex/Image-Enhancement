import cv2
from matplotlib import pyplot as plt
import numpy as np


img = cv2.imread('PenguinDistorted.bmp', 0)# This line loads the image into python from the local file directory



dft = cv2.dft(np.float32(img), flags=cv2.DFT_COMPLEX_OUTPUT)#Output is a 2D complex array. 1st channel real and 2nd imaginary, image also needs to be float value as input foe opencv

#Rearranges a Fourier transform X by shifting the zero-frequency
#component to the center of the array.
#Otherwise it starts at the tope left corenr of the image (array)
dft_shift = np.fft.fftshift(dft)
#This rearranges the fourier transform X by shifting the zero-freqency.
#This does not affect anything in the image as we shift back when we are finished applying a mask
#We did this so that the low frequency starts in the centre of the image rather than the left corner of the image


magnitude_spectrum = 20 * np.log(cv2.magnitude(dft_shift[:, :, 0], dft_shift[:, :, 1]))
#Using the function of fourier transform (20.log(abs(f))
#Values that are 0 the function returns intermediate values for log.
#Hence we add 1 to the array to avoid seeing a warning



#The code ionbelow is what was used to create the masks
#Each code section deals with creating a shape,radius and location
#Creates a mask from the shape in floating point  then applys the mask to the mask area.
#In order to add to the mask area, firstly we must define the maskarea by using "=" operator in python...
#To add to this mask we use the operator += which retains the previous value of mask_area and adds to it.
#In this case, it will add another circle to the mask area.
#When all the masks have been added to the mask area, the mask area is applied to the transform.

#top row
rows, cols = img.shape
r = 6

crow, ccol = int(34), int(53)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area = (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(34), int(155)
mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(34), int(255)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(34), int(357)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(34), int(461)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

#second row
crow, ccol = int(103), int(51)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(103), int(155)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(103), int(358)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(103), int(461)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(103), int(255)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
#middle row
crow, ccol = int(172), int(51)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(148)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(138)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(128)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(158)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(168)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(178)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(188)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(172), int(348)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(172), int(338)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(172), int(328)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(358)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(368)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(378)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(388)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(172), int(460)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

#fourth row
crow, ccol = int(240), int(460)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(240), int(359)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(240), int(51)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(240), int(153)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(240), int(256)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
#bottom row

crow, ccol = int(308), int(460)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(308), int(359)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(308), int(51)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(308), int(153)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(308), int(256)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(308), int(255)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

mask[mask_area] = 0
#mask area is set to 0 so that it removes the noise parts that the circles are now covering.

#end of masking


#this applies the mask to the magnitude spectrum by mutliplying the shift by the mask which adds to the spectrum.
fshift = dft_shift * mask


#Get the magnitude spectrum of the new spectrum, so that we can visually display the additon of the mask
fshift_mask_mag = 20 * np.log(cv2.magnitude(fshift[:, :, 0], fshift[:, :, 1]))

#inverse shift back to origin values (top left of the image)
f_ishift = np.fft.ifftshift(fshift)

#apply inverse DFT
img_back = cv2.idft(f_ishift, flags=cv2.DFT_SCALE)

img_back = cv2.magnitude(img_back[:, :, 0], img_back[:, :, 1])

cv2.imwrite('image.png',img_back)

fig = plt.figure(figsize=(12, 12))

ax1 = fig.add_subplot(2,2,1)
ax1.imshow(img, cmap='gray')
ax1.title.set_text('Input Image')
ax2 = fig.add_subplot(2,2,2)
ax2.imshow(magnitude_spectrum, cmap='gray')
ax2.title.set_text('FFT of image')
ax3 = fig.add_subplot(2,2,3)
ax3.imshow(fshift_mask_mag, cmap='gray')
ax3.title.set_text('FFT + Mask')
ax4 = fig.add_subplot(2,2,4)
ax4.imshow(img_back, cmap='gray')
ax4.title.set_text('After inverse FFT')
plt.show()


