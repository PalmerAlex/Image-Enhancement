import cv2
from matplotlib import pyplot as plt
import numpy as np


img = cv2.imread('PenguinDistorted.bmp', 0)# This line loads the image into python from the local file directory

img_orig = cv2.imread('PenguinOriginal(1).bmp', 0) # Original file


# This is the function we are going to use to calculate the MSE of our images


def mse(imageA, imageB):

    error = np.sum((imageA.astype("float") - imageB.astype("float")) ** 2)
    error /= float(imageA.shape[0] * imageA.shape[1])

    return error

dft = cv2.dft(np.float32(img), flags=cv2.DFT_COMPLEX_OUTPUT)#Output is a 2D complex array. 1st channel real and 2nd imaginary, image also needs to be float value as input foe opencv

#Rearranges a Fourier transform X by shifting the zero-frequency
#component to the center of the array.
#Otherwise it starts at the tope left corenr of the image (array)
dft_shift = np.fft.fftshift(dft)
#This rearranges the fourier transform X by shifting the zero-freqency.
#This does not affect anything in the image as we shift back when we are finished applying a mask
#We did this so that the low frequency starts in the centre of the image rather than the left corner of the image


magnitude_spectrum = 20 * np.log(cv2.magnitude(dft_shift[:, :, 0], dft_shift[:, :, 1]))
#Using the function of fourier transform (20.log(abs(f))
#Values that are 0 the function returns intermediate values for log.
#Hence we add 1 to the array to avoid seeing a warning



#The code ionbelow is what was used to create the masks
#Each code section deals with creating a shape,radius and location
#Creates a mask from the shape in floating point  then applys the mask to the mask area.
#In order to add to the mask area, firstly we must define the maskarea by using "=" operator in python...
#To add to this mask we use the operator += which retains the previous value of mask_area and adds to it.
#In this case, it will add another circle to the mask area.
#When all the masks have been added to the mask area, the mask area is applied to the transform.

#top row
rows, cols = img.shape
r = 6

crow, ccol = int(34), int(53)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area = (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(34), int(155)
mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(34), int(255)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(34), int(357)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(34), int(461)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

#second row
crow, ccol = int(103), int(51)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(103), int(155)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(103), int(358)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(103), int(461)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(103), int(255)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
#middle row
crow, ccol = int(172), int(51)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(148)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(138)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(128)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(158)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(168)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(178)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(188)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(172), int(348)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(172), int(338)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(172), int(328)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(358)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(368)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(378)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(172), int(388)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(172), int(460)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

#fourth row
crow, ccol = int(240), int(460)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(240), int(359)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(240), int(51)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(240), int(153)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(240), int(256)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
#bottom row

crow, ccol = int(308), int(460)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(308), int(359)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(308), int(51)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

crow, ccol = int(308), int(153)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(308), int(256)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r
crow, ccol = int(308), int(255)

mask = np.ones((rows, cols, 2), np.uint8)

center = [crow, ccol]
x, y = np.ogrid[:rows, :cols]
mask_area += (x - center[0]) ** 2 + (y - center[1]) ** 2 <= r*r

mask[mask_area] = 0
#mask area is set to 0 so that it removes the noise parts that the circles are now covering.

#end of masking


#this applies the mask to the magnitude spectrum by mutliplying the shift by the mask which adds to the spectrum.
fshift = dft_shift * mask


#Get the magnitude spectrum of the new spectrum, so that we can visually display the additon of the mask
fshift_mask_mag = 20 * np.log(cv2.magnitude(fshift[:, :, 0], fshift[:, :, 1]))

#inverse shift back to origin values (top left of the image)
f_ishift = np.fft.ifftshift(fshift)

#apply inverse DFT
img_back = cv2.idft(f_ishift, flags=cv2.DFT_SCALE)


img_back = cv2.magnitude(img_back[:, :, 0], img_back[:, :, 1])

fig = plt.figure(figsize=(12, 12))
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(img, cmap='gray')
ax1.title.set_text('Input Image')
ax2 = fig.add_subplot(2,2,2)
ax2.imshow(magnitude_spectrum, cmap='gray')
ax2.title.set_text('FFT of image')
ax3 = fig.add_subplot(2,2,3)
ax3.imshow(fshift_mask_mag, cmap='gray')
ax3.title.set_text('FFT + Mask')
ax4 = fig.add_subplot(2,2,4)
ax4.imshow(img_back, cmap='gray')
ax4.title.set_text('After inverse FFT')
plt.show()


# Removing Random Noise

# Testing the difference between a kernel of 3 and a kernel of 5 for Median filtering


med_blur_5 = cv2.medianBlur(img_back,5) # the first parameter is the image being blurred, the second parameter is the size of the kernel

med_blur_3 = cv2.medianBlur(img_back,3)

fig = plt.figure(figsize=(12, 12))
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(img_back, cmap='gray')
ax1.title.set_text('Filtered Image')
ax1 = fig.add_subplot(2,2,2)
ax1.imshow(img_back, cmap='gray')
ax1.title.set_text('Filtered Image')
ax1 = fig.add_subplot(2,2,3)
ax1.imshow(med_blur_3, cmap='gray')
ax1.title.set_text('Median Kernel Size = 3x3')
ax1 = fig.add_subplot(2,2,4)
ax1.imshow(med_blur_5, cmap='gray')
ax1.title.set_text('Median Kernel Size = 5x5')
plt.show()

print('Median Filter MSE Results')
print('MSE: Kernel = 3x3 ', mse(img_orig, med_blur_3))
print('MSE: Kernel = 5x5 ', mse(img_orig, med_blur_5))

# Testing different parameters on Mean filtering

mean_blur_3_5 = cv2.blur(img_back,(3,5)) # The first parameter (img_back) is the image being filtered
# in the second parameter (3,5) the 3 represent the kernel size and the 5 represent the Center value in the kernel
mean_blur_5_5 = cv2.blur(img_back,(5,5))
mean_blur_3_3 = cv2.blur(img_back,(3,3))
mean_blur_5_3 = cv2.blur(img_back,(5,3))

fig = plt.figure(figsize=(12, 12))
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(mean_blur_3_5, cmap='gray')
ax1.title.set_text('Mean Kernel Size = 3x3, Centre Value = 5')
ax1 = fig.add_subplot(2,2,2)
ax1.imshow(mean_blur_5_5, cmap='gray')
ax1.title.set_text('Mean Kernel Size = 5x5, Centre Value = 5')
ax1 = fig.add_subplot(2,2,3)
ax1.imshow(mean_blur_3_3, cmap='gray')
ax1.title.set_text('Mean Kernel Size = 3x3, Centre Value = 3')
ax1 = fig.add_subplot(2,2,4)
ax1.imshow(mean_blur_5_3, cmap='gray')
ax1.title.set_text('Mean Kernel Size = 5x5, Centre Value = 3')
plt.show()
print('Mean Filter MSE Results')
print('MSE: Kernel = 3x3 Center Value = 5: ', mse(img_orig, mean_blur_3_5))
print('MSE: Kernel = 5x5 Center Value = 5: ', mse(img_orig, mean_blur_5_5))
print('MSE: Kernel = 3x3 Center Value = 3: ', mse(img_orig, mean_blur_3_3))
print('MSE: Kernel = 5x5 Center Value = 3: ', mse(img_orig, mean_blur_5_3))

mean_blur_3_10 = cv2.blur(img_back,(3,10))
mean_blur_5_10 = cv2.blur(img_back,(5,10))
mean_blur_3_1 = cv2.blur(img_back,(3,1))
mean_blur_5_1 = cv2.blur(img_back,(5,1))

fig = plt.figure(figsize=(12, 12))
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(mean_blur_3_10, cmap='gray')
ax1.title.set_text('Mean Kernel Size = 3x3, Centre Value = 10')
ax1 = fig.add_subplot(2,2,2)
ax1.imshow(mean_blur_5_10, cmap='gray')
ax1.title.set_text('Mean Kernel Size = 5x5, Centre Value = 10')
ax1 = fig.add_subplot(2,2,3)
ax1.imshow(mean_blur_3_1, cmap='gray')
ax1.title.set_text('Mean Kernel Size = 3x3, Centre Value = 1')
ax1 = fig.add_subplot(2,2,4)
ax1.imshow(mean_blur_5_1, cmap='gray')
ax1.title.set_text('Mean Kernel Size = 5x5, Centre Value = 1')
plt.show()

print('MSE: Kernel = 3x3 Center Value = 10: ', mse(img_orig, mean_blur_3_10))
print('MSE: Kernel = 5x5 Center Value = 10: ', mse(img_orig, mean_blur_5_10))
print('MSE: Kernel = 3x3 Center Value = 1: ', mse(img_orig, mean_blur_3_1))
print('MSE: Kernel = 5x5 Center Value = 1: ', mse(img_orig, mean_blur_5_1))


# Testing different parameters on gaussian smoothing

gauss_blur_5_5_0 = cv2.GaussianBlur(img_back,(5,5),0) # The first parameter (img_back) is the image being filtered
# the second parameter (5,5) defines the size of the kernel in this case it will be 5x5
# the third parameter ( 0 ) represents the Sigma Values which define the deviation of the kernel

gauss_blur_3_3_0 = cv2.GaussianBlur(img_back,(3,3),0)
gauss_blur_5_5_20 = cv2.GaussianBlur(img_back,(5,5),20)
gauss_blur_3_3_20 = cv2.GaussianBlur(img_back,(3,3),20)

fig = plt.figure(figsize=(12, 12))
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(gauss_blur_3_3_0, cmap='gray')
ax1.title.set_text('Gauss Kernel = 3x3, Sigma Values = 0')
ax1 = fig.add_subplot(2,2,2)
ax1.imshow(gauss_blur_5_5_0, cmap='gray')
ax1.title.set_text('Gauss Kernel = 5x5, Sigma Values = 0')
ax1 = fig.add_subplot(2,2,3)
ax1.imshow(gauss_blur_3_3_20, cmap='gray')
ax1.title.set_text('Gauss Kernel = 3x3, Sigma Values = 20')
ax1 = fig.add_subplot(2,2,4)
ax1.imshow(gauss_blur_5_5_20, cmap='gray')
ax1.title.set_text('Gauss Kernel = 5x5, Sigma Values = 20')
plt.show()
print('Gaussian Smoothing MSE Results')
print('MSE: Kernel = 3x3 Sigma Values = 0: ', mse(img_orig, gauss_blur_3_3_0))
print('MSE: Kernel = 5x5 Sigma Values = 0: ', mse(img_orig, gauss_blur_5_5_0))
print('MSE: Kernel = 3x3 Sigma Values = 20: ', mse(img_orig, gauss_blur_3_3_20))
print('MSE: Kernel = 5x5 Sigma Values = 20: ', mse(img_orig, gauss_blur_5_5_20))

gauss_blur_5_11_0 = cv2.GaussianBlur(img_back,(5,11),0)
gauss_blur_3_11_0 = cv2.GaussianBlur(img_back,(3,11),0)
gauss_blur_5_11_20 = cv2.GaussianBlur(img_back,(5,11),20)
gauss_blur_3_11_20 = cv2.GaussianBlur(img_back,(3,11),20)

fig = plt.figure(figsize=(12, 12))
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(gauss_blur_3_11_0, cmap='gray')
ax1.title.set_text('Gauss Kernel = 3x11, Sigma Values = 0')
ax1 = fig.add_subplot(2,2,2)
ax1.imshow(gauss_blur_5_11_0, cmap='gray')
ax1.title.set_text('Gauss Kernel = 5x11, Sigma Values = 0')
ax1 = fig.add_subplot(2,2,3)
ax1.imshow(gauss_blur_3_11_20, cmap='gray')
ax1.title.set_text('Gauss Kernel = 3x11, Sigma Values = 20')
ax1 = fig.add_subplot(2,2,4)
ax1.imshow(gauss_blur_5_11_20, cmap='gray')
ax1.title.set_text('Gauss Kernel = 5x11, Sigma Values = 20')
plt.show()
print('MSE: Kernel = 3x11 Sigma Values = 0: ', mse(img_orig, gauss_blur_3_11_0))
print('MSE: Kernel = 5x11 Sigma Values = 0: ', mse(img_orig, gauss_blur_5_11_0))
print('MSE: Kernel = 3x11 Sigma Values = 20: ', mse(img_orig, gauss_blur_3_11_20))
print('MSE: Kernel = 5x11 Sigma Values = 20: ', mse(img_orig, gauss_blur_5_11_20))

gauss_blur_11_11_0 = cv2.GaussianBlur(img_back,(11,11),0)
gauss_blur_23_23_0 = cv2.GaussianBlur(img_back,(23,23),0)
gauss_blur_11_11_20 = cv2.GaussianBlur(img_back,(11,11),20)
gauss_blur_23_23_20 = cv2.GaussianBlur(img_back,(23,23),20)

fig = plt.figure(figsize=(12, 12))
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(gauss_blur_11_11_0, cmap='gray')
ax1.title.set_text('Gauss Kernel = 11x11, Sigma Values = 0')
ax1 = fig.add_subplot(2,2,2)
ax1.imshow(gauss_blur_23_23_0, cmap='gray')
ax1.title.set_text('Gauss Kernel = 23x23, Sigma Values = 0')
ax1 = fig.add_subplot(2,2,3)
ax1.imshow(gauss_blur_11_11_20, cmap='gray')
ax1.title.set_text('Gauss Kernel = 11x11, Sigma Values = 20')
ax1 = fig.add_subplot(2,2,4)
ax1.imshow(gauss_blur_23_23_20, cmap='gray')
ax1.title.set_text('Gauss Kernel = 23x23, Sigma Values = 20')
plt.show()

print('MSE: Kernel = 11x11 Sigma Values = 0: ', mse(img_orig, gauss_blur_11_11_0))
print('MSE: Kernel = 23x23 Sigma Values = 0: ', mse(img_orig, gauss_blur_23_23_0))
print('MSE: Kernel = 11x11 Sigma Values = 20: ', mse(img_orig, gauss_blur_11_11_20))
print('MSE: Kernel = 23x23 Sigma Values= 20: ', mse(img_orig, gauss_blur_23_23_20))

# Applying the filters 4 times to the image

# Applying Median Filtering 4 times

med_blur_1 = cv2.medianBlur(img_back,5)

med_blur_2 = cv2.medianBlur(med_blur_1,5)

med_blur_3 = cv2.medianBlur(med_blur_2,5)

med_blur_4 = cv2.medianBlur(med_blur_3,5)


fig = plt.figure(figsize=(12, 12))
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(med_blur_1, cmap='gray')
ax1.title.set_text('Median Filter 1st Time')
ax1 = fig.add_subplot(2,2,2)
ax1.imshow(med_blur_2, cmap='gray')
ax1.title.set_text('Median Filter 2nd Time')
ax1 = fig.add_subplot(2,2,3)
ax1.imshow(med_blur_3, cmap='gray')
ax1.title.set_text('Median Filter 3rd Time')
ax1 = fig.add_subplot(2,2,4)
ax1.imshow(med_blur_4, cmap='gray')
ax1.title.set_text('Median Filter 4th Time')
plt.show()
print('Median Filter')
print('MSE 1st: ', mse(img_orig, med_blur_1 ))
print('MSE 2nd: ', mse(img_orig, med_blur_2 ))
print('MSE 3rd: ', mse(img_orig, med_blur_3 ))
print('MSE 4th: ', mse(img_orig, med_blur_4 ))

# Applying Mean filtering 4 times

mean_blur_1 = cv2.blur(img_back,(5,3))

mean_blur_2 = cv2.blur(mean_blur_1,(5,3))

mean_blur_3 = cv2.blur(mean_blur_2,(5,3))

mean_blur_4 = cv2.blur(mean_blur_3,(5,3))

fig = plt.figure(figsize=(12, 12))
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(mean_blur_1, cmap='gray')
ax1.title.set_text('Mean Filter 1st Time')
ax1 = fig.add_subplot(2,2,2)
ax1.imshow(mean_blur_2, cmap='gray')
ax1.title.set_text('Mean Filter 2nd Time')
ax1 = fig.add_subplot(2,2,3)
ax1.imshow(mean_blur_3, cmap='gray')
ax1.title.set_text('Mean Filter 3rd Time')
ax1 = fig.add_subplot(2,2,4)
ax1.imshow(mean_blur_4, cmap='gray')
ax1.title.set_text('Mean Filter 4th Time')
plt.show()
print('Mean Filter')
print('MSE 1st: ', mse(img_orig, mean_blur_1 ))
print('MSE 2nd: ', mse(img_orig, mean_blur_2 ))
print('MSE 3rd: ', mse(img_orig, mean_blur_3 ))
print('MSE 4th: ', mse(img_orig, mean_blur_4 ))

# Applying Gaussian Smoothing 4 times

gauss_blur_1 = cv2.GaussianBlur(img_back,(5,5),0)

gauss_blur_2 = cv2.GaussianBlur(gauss_blur_1,(5,5),0)

gauss_blur_3 = cv2.GaussianBlur(gauss_blur_2,(5,5),0)

gauss_blur_4 = cv2.GaussianBlur(gauss_blur_3,(5,5),0)

fig = plt.figure(figsize=(12, 12))
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(gauss_blur_1, cmap='gray')
ax1.title.set_text('Gaussian Smoothing 1st Time')
ax1 = fig.add_subplot(2,2,2)
ax1.imshow(gauss_blur_2, cmap='gray')
ax1.title.set_text('Gaussian Smoothing 2nd Time')
ax1 = fig.add_subplot(2,2,3)
ax1.imshow(gauss_blur_3, cmap='gray')
ax1.title.set_text('Gaussian Smoothing 3rd Time')
ax1 = fig.add_subplot(2,2,4)
ax1.imshow(gauss_blur_4, cmap='gray')
ax1.title.set_text('Gaussian Smoothing 4th Time')
plt.show()
print('Gaussian Smoothing')
print('MSE 1st: ', mse(img_orig, gauss_blur_1 ))
print('MSE 2nd: ', mse(img_orig, gauss_blur_2 ))
print('MSE 3rd: ', mse(img_orig, gauss_blur_3 ))
print('MSE 4th: ', mse(img_orig, gauss_blur_4 ))


# 1st filter combination: 2 Median - Gaussian - Mean

med_blur_seq_1 = cv2.medianBlur(img_back,5)
med_blur_seq_2 = cv2.medianBlur(med_blur_seq_1,5)
gauss_blur_seq_3 = cv2.GaussianBlur(med_blur_seq_2,(5,5),0)
mean_blur_seq_4 = cv2.blur(gauss_blur_seq_3 ,(5,3))

fig = plt.figure(figsize=(12, 12))
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(med_blur_seq_1, cmap='gray')
ax1.title.set_text('Median Filter 1st filter')
ax1 = fig.add_subplot(2,2,2)
ax1.imshow(med_blur_seq_2, cmap='gray')
ax1.title.set_text('Median Filter 2nd filter')
ax1 = fig.add_subplot(2,2,3)
ax1.imshow(gauss_blur_seq_3, cmap='gray')
ax1.title.set_text('Gaussian Smoothing 3rd filter')
ax1 = fig.add_subplot(2,2,4)
ax1.imshow(mean_blur_seq_4, cmap='gray')
ax1.title.set_text('Mean Filter 4th filter')
plt.show()
print('MSE Results for 2 Median - Gaussian  - Mean')
print('MSE: 1st Filter Applied: ', mse(img_orig, med_blur_seq_1))
print('MSE: 2nd Filter Applied: ', mse(img_orig, med_blur_seq_2))
print('MSE: 3rd Filter Applied: ', mse(img_orig, gauss_blur_seq_3))
print('MSE: 4th Filter Applied: ', mse(img_orig, mean_blur_seq_4))

# 2nd filter combination: Mean - Median - Gaussian - Median

mean_blur_seq_1 = cv2.blur(img_back,(5,3))
med_blur_seq_2 = cv2.medianBlur(mean_blur_seq_1,5)
gauss_blur_seq_3 = cv2.GaussianBlur(med_blur_seq_2,(5,5),0)
med_blur_seq_4 = cv2.medianBlur(gauss_blur_seq_3,5)

fig = plt.figure(figsize=(12, 12))
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(mean_blur_seq_1, cmap='gray')
ax1.title.set_text('Mean Filter 1st filter')
ax1 = fig.add_subplot(2,2,2)
ax1.imshow(med_blur_seq_2, cmap='gray')
ax1.title.set_text('Median Filter 2nd filter')
ax1 = fig.add_subplot(2,2,3)
ax1.imshow(gauss_blur_seq_3, cmap='gray')
ax1.title.set_text('Gaussian Smoothing 3rd filter')
ax1 = fig.add_subplot(2,2,4)
ax1.imshow(med_blur_seq_4, cmap='gray')
ax1.title.set_text('Mean Filter 4th filter')
plt.show()

print('MSE Results for Mean - Median - Gaussian - Median')
print('MSE: 1st Filter Applied: ', mse(img_orig, mean_blur_seq_1))
print('MSE: 2nd Filter Applied: ', mse(img_orig, med_blur_seq_2))
print('MSE: 3rd Filter Applied: ', mse(img_orig, gauss_blur_seq_3))
print('MSE: 4th Filter Applied: ', mse(img_orig, mean_blur_seq_4))

# 3rd filter combination: 2 Gaussian, Median, Mean

gauss_blur_seq_1 = cv2.GaussianBlur(img_back,(5,5),0)
gauss_blur_seq_2 = cv2.GaussianBlur(gauss_blur_seq_1,(5,5),0)
med_blur_seq_3 = cv2.medianBlur(gauss_blur_seq_2,5)
mean_blur_seq_4 = cv2.blur(med_blur_seq_3,(5,3))

fig = plt.figure(figsize=(12, 12))
ax1 = fig.add_subplot(2,2,1)
ax1.imshow(gauss_blur_seq_1, cmap='gray')
ax1.title.set_text('Gaussian Smoothing 1st filter')
ax1 = fig.add_subplot(2,2,2)
ax1.imshow(gauss_blur_seq_2, cmap='gray')
ax1.title.set_text('Gaussian Smoothing 2nd filter')
ax1 = fig.add_subplot(2,2,3)
ax1.imshow(med_blur_seq_3, cmap='gray')
ax1.title.set_text('Median Filter 3rd filter')
ax1 = fig.add_subplot(2,2,4)
ax1.imshow(mean_blur_seq_4 , cmap='gray')
ax1.title.set_text('Mean Filter 4th filter')
plt.show()

print('MSE Results for 2 Gaussian, Median, Mean')
print('MSE: 1st Filter Applied: ', mse(img_orig, gauss_blur_seq_1))
print('MSE: 2nd Filter Applied: ', mse(img_orig, gauss_blur_seq_2))
print('MSE: 3rd Filter Applied: ', mse(img_orig, med_blur_seq_3))
print('MSE: 4th Filter Applied: ', mse(img_orig, mean_blur_seq_4))


# MSE between the original image with the distorted image

print('MSE Original VS Distorted ', mse(img_orig, img))

print('MSE Original VS Image without Periodic noise ', mse(img_orig, img_back))

